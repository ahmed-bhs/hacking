Nautilus File Manager Integration
---------------------------------

1) Change the JD-GUI path in "open-in-jd-gui.sh".
2) Copy the script into your scripts folder "~/.gnome2/nautilus-scripts".

