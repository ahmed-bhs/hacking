#!/bin/sh
#On Ubuntu 64bits

apt-get install libgtk2.0-0:i386 libxxf86vm1:i386 libsm6:i386 lib32stdc++6 -y

